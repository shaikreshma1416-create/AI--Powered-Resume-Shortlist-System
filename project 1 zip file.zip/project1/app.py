from flask import Flask, render_template, request
import os


from utils.parser import (
    extract_text_from_pdf,
    extract_email,
    extract_phone
)


from utils.preprocess import clean_text


from utils.matching import calculate_similarity


from utils.skills import (
    extract_skills,
    skill_match,
    missing_skills
)



app = Flask(__name__)


UPLOAD_FOLDER = "uploads"

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER



# Create uploads folder

if not os.path.exists(UPLOAD_FOLDER):

    os.makedirs(UPLOAD_FOLDER)





@app.route("/")
def home():

    return render_template(
        "index.html"
    )






@app.route("/analyze", methods=["POST"])
def analyze():


    try:


        # -----------------------------
        # Get Resume File
        # -----------------------------

        resume = request.files.get("resume")


        if resume is None or resume.filename == "":

            return "Please upload resume PDF"





        # -----------------------------
        # Get Job Description
        # -----------------------------

        job_description = request.form.get(
            "job_description"
        )


        if not job_description:

            return "Please enter job description"






        # -----------------------------
        # Save Resume
        # -----------------------------

        filepath = os.path.join(

            UPLOAD_FOLDER,

            resume.filename

        )


        resume.save(filepath)






        # -----------------------------
        # Extract PDF Text
        # -----------------------------

        resume_text = extract_text_from_pdf(

            filepath

        )



        if not resume_text:

            return "Unable to read resume PDF"







        # -----------------------------
        # Extract Email & Phone
        # Before Cleaning
        # -----------------------------

        email = extract_email(

            resume_text

        )


        phone = extract_phone(

            resume_text

        )







        # -----------------------------
        # Clean Text
        # -----------------------------

        clean_resume_text = clean_text(

            resume_text

        )


        clean_job_text = clean_text(

            job_description

        )









        # -----------------------------
        # Skills Extraction
        # -----------------------------

        resume_skills = extract_skills(

            clean_resume_text

        )


        job_skills = extract_skills(

            clean_job_text

        )



        print("====================")
        print("Resume Skills:", resume_skills)
        print("Job Skills:", job_skills)
        print("====================")









        # -----------------------------
        # AI Similarity
        # -----------------------------

        ai_score = calculate_similarity(

            clean_resume_text,

            clean_job_text

        )








        # -----------------------------
        # Skill Matching
        # -----------------------------

        skill_score = skill_match(

            resume_skills,

            job_skills

        )






        print("AI SCORE:", ai_score)

        print("SKILL SCORE:", skill_score)








        # -----------------------------
        # Final ATS Score
        # -----------------------------

        final_score = round(

            (ai_score * 0.6)

            +

            (skill_score * 0.4),

            2

        )








        # -----------------------------
        # Missing Skills
        # -----------------------------

        missing = missing_skills(

            resume_skills,

            job_skills

        )








        # -----------------------------
        # Decision
        # -----------------------------

        if final_score >= 80:

            decision = "SHORTLISTED"


        elif final_score >= 50:

            decision = "REVIEW"


        else:

            decision = "REJECTED"









        # -----------------------------
        # Send Result Page
        # -----------------------------

        return render_template(

            "result.html",

            filename=resume.filename,

            score=final_score,

            ai_score=ai_score,

            skill_score=skill_score,

            skills=resume_skills,

            missing=missing,

            decision=decision,

            email=email if email else "Not Found",

            phone=phone if phone else "Not Found"

        )






    except Exception as e:


        print("ERROR:", e)

        return f"Error occurred: {e}"









if __name__ == "__main__":


    app.run(

        debug=True

    )