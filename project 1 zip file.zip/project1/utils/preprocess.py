import re
import nltk

from nltk.corpus import stopwords


nltk.download("stopwords")


def clean_text(text):

    text = text.lower()

    text = re.sub(
        r"[^a-zA-Z ]",
        "",
        text
    )

    words = text.split()

    stop_words = set(stopwords.words("english"))

    filtered_words = []

    for word in words:

        if word not in stop_words:

            filtered_words.append(word)


    return " ".join(filtered_words)