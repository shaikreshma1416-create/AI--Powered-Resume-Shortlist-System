import re
import PyPDF2



def extract_text_from_pdf(filepath):

    text = ""

    with open(filepath, "rb") as file:

        reader = PyPDF2.PdfReader(file)


        for page in reader.pages:

            page_text = page.extract_text()

            if page_text:

                text += page_text


    return text





def extract_email(text):

    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'


    email = re.findall(
        email_pattern,
        text
    )


    if email:

        return email[0]


    return "Not Found"






def extract_phone(text):


    # Remove extra spaces/new lines

    text = text.replace("\n"," ")



    phone_pattern = r'(\+91[\s-]?\d{10}|\d{10})'



    phone = re.findall(

        phone_pattern,

        text

    )



    if phone:


        number = phone[0]


        # formatting

        if not number.startswith("+91"):

            number = "+91 " + number


        return number



    return "Not Found"