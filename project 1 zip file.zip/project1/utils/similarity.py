from sentence_transformers import SentenceTransformer

from sklearn.metrics.pairwise import cosine_similarity



model = SentenceTransformer(
    "all-MiniLM-L6-v2"
)



def calculate_similarity(resume, job_description):


    resume_vector = model.encode(
        resume
    )


    job_vector = model.encode(
        job_description
    )


    score = cosine_similarity(
        [resume_vector],
        [job_vector]
    )


    return round(
        float(score[0][0])*100,
        2
    )