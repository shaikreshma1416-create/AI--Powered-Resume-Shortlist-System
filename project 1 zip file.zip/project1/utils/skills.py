import re


SKILL_LIST = [

    "python",
    "java",
    "c++",
    "sql",
    "mysql",
    "machine learning",
    "deep learning",
    "artificial intelligence",
    "ai",
    "data science",
    "data analysis",
    "pandas",
    "numpy",
    "tensorflow",
    "pytorch",
    "flask",
    "django",
    "html",
    "css",
    "javascript",
    "react",
    "node",
    "git",
    "github",
    "docker",
    "aws",
    "azure",
    "linux",
    "excel",
    "power bi",
    "tableau",
    "nlp",
    "natural language processing"

]



def extract_skills(text):

    text = text.lower()

    found = []


    for skill in SKILL_LIST:

        if skill in text:

            found.append(skill)


    return list(set(found))





def skill_match(resume_skills, job_skills):

    if len(job_skills) == 0:

        return 0


    matched = set(resume_skills).intersection(
        set(job_skills)
    )


    score = (
        len(matched)
        /
        len(job_skills)
    ) * 100


    return round(score,2)





def missing_skills(resume_skills, job_skills):

    missing = set(job_skills) - set(resume_skills)

    return list(missing)